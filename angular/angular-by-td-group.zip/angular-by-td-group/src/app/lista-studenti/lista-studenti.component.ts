import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudenteVO } from '@app/shared/vo/studente.vo';

@Component({
  selector: 'app-lista-studenti',
  templateUrl: './lista-studenti.component.html',
  styleUrls: ['./lista-studenti.component.scss']
})
export class ListaStudentiComponent implements OnInit {

  @Input() studenti?: StudenteVO[];
  @Input() showDetail = false; //Per lista con ricerca

  constructor(private router: Router) { }

  ngOnInit() {
  }

  //Per lista con ricerca
  goToStudentDetail(studentId: string): void {
    console.log("[ListaStudentiComponent.goToStudentDetail] studentId: ", studentId)
    this.router.navigate(["/dettaglio-studente/" + studentId]);
  }

}
