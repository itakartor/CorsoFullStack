import { Component, OnInit } from '@angular/core';
import { StudenteVO } from '@app/shared/vo/studente.vo';

@Component({
  selector: 'app-crea-studente',
  templateUrl: './crea-studente.component.html',
  styleUrls: ['./crea-studente.component.scss']
})
export class CreaStudenteComponent implements OnInit {

  colors = ['#000000', '#1a9c3d', '#a6114a', '#1353d4', '#6c17ad', '#0fd6c9'];


  studente: StudenteVO;
  public listaStudenti: StudenteVO[];

  submitted = false;

  constructor() {
    this.studente = new StudenteVO();
    this.listaStudenti = new Array<StudenteVO>();


  }

  ngOnInit() {
  }


  onSubmit() {
    this.submitted = true;
  }


  nuovoStudente(): void {
    this.studente = new StudenteVO();
  }

  salvaStudente(): void {
    this.listaStudenti.push(this.studente);
    this.nuovoStudente();
    this.submitted = false;
  }


}
