import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lista-studenti-material',
  templateUrl: './lista-studenti-material.component.html',
  styleUrls: ['./lista-studenti-material.component.scss']
})
export class ListaStudentiMaterialComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
