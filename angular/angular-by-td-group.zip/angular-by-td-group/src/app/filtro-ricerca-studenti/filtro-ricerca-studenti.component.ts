import { Component, OnInit, Output, EventEmitter  } from '@angular/core';

@Component({
  selector: 'app-filtro-ricerca-studenti',
  templateUrl: './filtro-ricerca-studenti.component.html',
  styleUrls: ['./filtro-ricerca-studenti.component.scss']
})
export class FiltroRicercaStudentiComponent implements OnInit {

  @Output() filtroNomeEvent = new EventEmitter<string>();

  nome: string;

  constructor() { }

  ngOnInit() {
  }

  emitFiltroRicerca(value: string): void {
    this.filtroNomeEvent.emit(value);
  }

}
