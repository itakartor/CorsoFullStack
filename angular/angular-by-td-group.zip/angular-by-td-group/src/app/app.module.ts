import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LayoutModule } from '@angular/cdk/layout';
import { CreaStudenteComponent } from './crea-studente/crea-studente.component';
import { CreaStudenteEListaStudentiComponent } from './crea-studente-e-lista-studenti/crea-studente-e-lista-studenti.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ListaStudentiComponent } from './lista-studenti/lista-studenti.component';
import { FiltroRicercaStudentiComponent } from './filtro-ricerca-studenti/filtro-ricerca-studenti.component';
import { RicercaStudentiComponent } from './ricerca-studenti/ricerca-studenti.component';
import { ListaStudentiMaterialComponent } from './lista-studenti-material/lista-studenti-material.component';
import { HeaderComponent } from './header/header.component';
import { NavBarComponent } from './nav-bar/nav-bar.component';
import { SharedServicesModule } from '@services/shared-services.module';
import { DettaglioStudenteComponent } from './dettaglio-studente/dettaglio-studente.component';




@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    CreaStudenteComponent,
    CreaStudenteEListaStudentiComponent,
    DashboardComponent,
    ListaStudentiComponent,
    FiltroRicercaStudentiComponent,
    RicercaStudentiComponent,
    ListaStudentiMaterialComponent,
    NavBarComponent,
    DettaglioStudenteComponent
  ],
  imports: [
    BrowserModule,
    CommonModule,
    FormsModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    LayoutModule,
    SharedServicesModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
