import { Component, OnInit } from '@angular/core';
import { StudentiService } from '@app/shared/services/studenti.service';
import { StudenteVO } from '@app/shared/vo/studente.vo';

@Component({
  selector: 'app-ricerca-studenti',
  templateUrl: './ricerca-studenti.component.html',
  styleUrls: ['./ricerca-studenti.component.scss']
})
export class RicercaStudentiComponent implements OnInit {

  //NOTA: ci sono diversi modi di implementare il recupero e la visualizzazione della lista
  //ad esempio, di solito si passa il filtro direttamente in una chiamata al BE, questo è un filtro il locale
  //quindi la chiamata al BE viene fatta solamente una volta, ma anche questa scelta implementativa va analizzata caso per caso
  listaStudenti: StudenteVO[]; //Lista passata al componente per la visualizzazione
  originalStudentList: StudenteVO[]; //Lista ricevuta dal be e mai filtrata

  constructor(private studentiService: StudentiService) {
  }

  ngOnInit() {
    this.studentiService.getListaStudenti().subscribe((studentList: StudenteVO[]) => {
        this.originalStudentList = studentList;
        this.listaStudenti = studentList;
    });
  }

  filtraListaStudenti(filtroNome: string): void {

    if (filtroNome) {
      this.listaStudenti = this.originalStudentList.filter((studente: StudenteVO) => studente.nome.toLowerCase().includes(filtroNome.toLowerCase()));
    } else{
      this.listaStudenti = this.originalStudentList;
    }

  }

}
