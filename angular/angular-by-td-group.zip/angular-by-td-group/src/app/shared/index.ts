export * from "./services/shared-services.module";
