import { Injectable } from "@angular/core";
import { Observable, of, throwError } from "rxjs";
import { StudenteVO } from "@vo/studente.vo";
import { STUDENTI } from '@app/shared/data/mock-studenti';


@Injectable()
export class StudentiService {
    constructor() {}

    getListaStudenti(): Observable<StudenteVO[]> {
      return of(STUDENTI);
    }

    getStudenteById(id: string): Observable<StudenteVO> {
      const studente = STUDENTI.filter((studente: StudenteVO) => studente.id === id);
      return of(studente?.length == 1 ? studente[0] : null);
      //Equivalente a questo
      // if(studente?.length == 1){
      //   return of(studente[0]);
      // } else {
      //   return of(null);
      // }
    }
}



//ESEMPIO PARZIALE DI CHIAMATA HTTP REALE (GET)
// import { HttpClient } from "@angular/common/http";
// import { map } from "rxjs/operators";
// import { StudenteMapper } from "@mapper/studente.mapper";
// import { StudenteDTO } from "@dto/studente.dto";


// @Injectable()
// export class StudentiService {
//     constructor(
//         private http: HttpClient,
//         private studenteMapper: StudenteMapper,
//     ) {}

//     getListaStudenti(): Observable<StudenteVO[]> {
//       const url = " INSERIRE LA URL QUI PER IL RECUPERO DELLA LISTA STUDENTI";
//       console.log("[StudentiService.getListaStudenti] url", url);
//       return this.http.get(url).pipe(map((resultList: StudenteDTO[]) => this.studenteMapper.convertListDtoToVo(resultList)));
//     }

// }
