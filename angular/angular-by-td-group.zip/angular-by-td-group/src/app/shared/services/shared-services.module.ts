import { CommonModule, DatePipe } from "@angular/common";
import { HttpClientModule } from "@angular/common/http";
import { NgModule } from "@angular/core";
import { StudenteMapper } from "@mapper/studente.mapper";
import { StudentiService } from '@app/shared/services/studenti.service';



const mappers = [
  StudenteMapper
];
const services = [
  StudentiService
];

@NgModule({
    imports: [CommonModule, HttpClientModule],
    declarations: [],
    providers: [mappers, services, DatePipe],
})
export class SharedServicesModule {}
