

import { MapperInterface } from "@mapper/mapper.interface";
import { StudenteDTO } from "@dto/studente.dto";
import { StudenteVO } from "@vo/studente.vo";

export class StudenteMapper implements MapperInterface<StudenteDTO, StudenteVO> {

    constructor() { }

    convertVoToDto(vo: StudenteVO): StudenteDTO {
        if (vo != null) {
            const dto = new StudenteDTO();
            dto.id = vo.id;
            dto.nome = vo.nome;
            dto.cognome = vo.cognome;
            dto.matricola = vo.matricola;
            dto.voto = vo.voto;
            //nota: il campo "avatarColor" non è presente nel dto quindi non viene mappato
            return dto;
        } else {
            return null;
        }
    }

    convertDtoToVo(dto: StudenteDTO): StudenteVO {
        if (dto != null) {
            const vo = new StudenteVO();
            vo.id = dto.id;
            vo.nome = dto.nome.toUpperCase();
            vo.cognome = dto.cognome.toUpperCase();
            vo.matricola = dto.matricola;
            vo.voto = dto.voto;
            //nota: il campo "avatarColor" non è presente nel dto quindi assegniamo genero un valore a caso)
            vo.avatarColor = "#" + Math.floor(Math.random()*16777215).toString(16);
            return vo;
        } else {
            return null;
        }
    }

    convertListVoToDto(voList: StudenteVO[]): StudenteDTO[] {
        if (voList != null) {
            return voList.map(vo => this.convertVoToDto(vo));
        } else {
            return null;
        }
    }

    convertListDtoToVo(dtoList: StudenteDTO[]): StudenteVO[] {
        if (dtoList != null) {
            return dtoList.map(dto => this.convertDtoToVo(dto));
        } else {
            return null;
        }
    }
}
