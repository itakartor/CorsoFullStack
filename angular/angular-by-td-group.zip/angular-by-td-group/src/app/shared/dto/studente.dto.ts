export class StudenteDTO {
    id: string;
    nome: string;
    cognome: string;
    matricola: string;
    voto: number;
}
