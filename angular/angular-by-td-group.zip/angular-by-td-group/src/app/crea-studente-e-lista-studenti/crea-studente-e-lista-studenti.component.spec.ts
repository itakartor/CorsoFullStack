/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { CreaStudenteEListaStudentiComponent } from './crea-studente-e-lista-studenti.component';

describe('CreaStudenteEListaStudentiComponent', () => {
  let component: CreaStudenteEListaStudentiComponent;
  let fixture: ComponentFixture<CreaStudenteEListaStudentiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreaStudenteEListaStudentiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreaStudenteEListaStudentiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
