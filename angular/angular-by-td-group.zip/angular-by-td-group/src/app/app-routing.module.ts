import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CreaStudenteEListaStudentiComponent } from './crea-studente-e-lista-studenti/crea-studente-e-lista-studenti.component';
import { CreaStudenteComponent } from './crea-studente/crea-studente.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { DettaglioStudenteComponent } from './dettaglio-studente/dettaglio-studente.component';
import { RicercaStudentiComponent } from './ricerca-studenti/ricerca-studenti.component';

const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'crea-studente', component: CreaStudenteEListaStudentiComponent },
  { path: 'crea-studente-refactored', component: CreaStudenteComponent }, //NOTA: non usare path con "refactored" qui è solo a scopo didattico
  { path: 'ricerca-studenti', component: RicercaStudentiComponent },
  { path: 'dettaglio-studente/:id', component: DettaglioStudenteComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
