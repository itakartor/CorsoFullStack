import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { StudenteDTO } from '@app/shared/dto/studente.dto';
import { StudentiService } from '@app/shared/services/studenti.service';
import { StudenteVO } from '@app/shared/vo/studente.vo';
import { catchError } from "rxjs/operators";
import { of } from "rxjs";

@Component({
  selector: 'app-dettaglio-studente',
  templateUrl: './dettaglio-studente.component.html',
  styleUrls: ['./dettaglio-studente.component.scss']
})
export class DettaglioStudenteComponent implements OnInit {

  studente?: StudenteVO;

  constructor(private route: ActivatedRoute, private studentiService: StudentiService) { }

  ngOnInit() {
    this.getStudent();
  }

  getStudent(): void {
    const id: string = this.route.snapshot.paramMap.get('id');
    this.studentiService.getStudenteById(id).subscribe((studente: StudenteVO) => {
      this.studente = studente;
    });
  }

}
