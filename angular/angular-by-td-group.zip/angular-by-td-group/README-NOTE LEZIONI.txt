Sono state inportate le seguenti librerie:

1) Fontawesome: per le icone
2) Bootstrap:
   (per importare la v4 nel package.json cambiare in: "bootstrap": "^4.6.0"
    per importare la v5 nel package.json cambiare in: "bootstrap": "^5.1.3",)
3) Angular Material: potrebbe andare in conflitto con bootstrap su qualche stile
4) Prime NG: al momento non sono importanti i css per farlo nel angular.json tra gli stili aggiungere
              "./node_modules/primeng/resources/themes/saga-blue/theme.css",
              "./node_modules/primeng/resources/primeng.min.css",
              "./node_modules/primeicons/primeicons.css",



//GENERAZIONE DI UN NUOVO PROGETTO
1) ng new nome-progetto
	y
	SCSS



//ISTALLAZIONE DI:

1) Bootstrap:
	https://www.npmjs.com/package/bootstrap
	https://loiane.com/2017/08/how-to-add-bootstrap-to-an-angular-cli-project/
	npm install bootstrap  //Istalla la 5 che ha qualche tag modificato, una vecchia versione è     "bootstrap": "^4.6.0",
2) Fontawesome
	https://fontawesome.com/
	https://fontawesome.com/v5.15/how-to-use/on-the-web/setup/using-package-managers
	npm install --save @fortawesome/fontawesome-free
	//NO! poi usarlo sembra più complicato: npm i @fortawesome/angular-fontawesome
3) Angular Material
	https://material.angular.io/
	https://material.angular.io/guide/getting-started
	ng add @angular/material

4) Prima NG
	https://www.primefaces.org/primeng/showcase/#/setup

	npm install primeng --save
	npm install primeicons --save


//MODIFICHE STRUTTURALI AL TEMPLATE BASE
1) Wrapping di styles.scss in una struttura più complessa per dividere meglio i fogli di stile,
   per questa operazione va anche modificato il path nell'angular.json
2) In asset messa la directory images
3)nel tsconfig.json
  - impostato  ->    "strict": false,
  - commentate:
    // "strictInjectionParameters": true,
    // "strictInputAccessModifiers": true,
    // "strictTemplates": true

  - aggiunto in tsconfig.json, tsconfig.app.json, tsconfig.spec.json :
    "paths": {
      "@app/*": [
        "app/*"
      ], // root app
      "@env/*": [
        "environments/*"
      ], // env config
      "@dto/*": [
        "app/shared/dto/*"
      ],
      "@vo/*": [
        "app/shared/vo/*"
      ],
      "@services/*": [
        "app/shared/services/*"
      ],
      "@mapper/*": [
        "app/shared/mapper/*"
      ],
      "@store/*": [
        "app/shared/store/*"
      ]
    }



//COMANDI UTILI
1) Istallazione del node_modules
	npm install
2) Run dell'applicazione
	npm start
3) Build dell'applicazione
	npm run build











